// پل JNI بین جاوا و whisper.cpp
#include <jni.h>
#include <android/log.h>

#include <string>

#include "whisper.h"

#define LOG_TAG "UnitVoiceWhisper"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

extern "C" JNIEXPORT jlong JNICALL
Java_ir_semnan_unitvoice_LocalWhisper_nativeInit(JNIEnv *env, jclass, jstring model_path) {
    const char *path = env->GetStringUTFChars(model_path, nullptr);
    if (path == nullptr) {
        return 0;
    }
    struct whisper_context_params cparams = whisper_context_default_params();
    cparams.use_gpu = false;
    struct whisper_context *ctx = whisper_init_from_file_with_params(path, cparams);
    env->ReleaseStringUTFChars(model_path, path);
    LOGI("model loaded: %s", ctx != nullptr ? "ok" : "FAILED");
    return reinterpret_cast<jlong>(ctx);
}

// خروجی را به‌صورت بایت‌های UTF-8 برمی‌گردانیم (و در جاوا تبدیل می‌کنیم)، چون
// NewStringUTF با بایت‌های ناقصِ UTF-8 که گاهی از مدل می‌آید خطا می‌دهد.
extern "C" JNIEXPORT jbyteArray JNICALL
Java_ir_semnan_unitvoice_LocalWhisper_nativeTranscribe(JNIEnv *env, jclass, jlong handle,
                                                       jfloatArray samples, jint threads,
                                                       jint audio_ctx) {
    struct whisper_context *ctx = reinterpret_cast<struct whisper_context *>(handle);
    std::string text;

    if (ctx != nullptr && samples != nullptr) {
        const jsize n = env->GetArrayLength(samples);
        jfloat *data = env->GetFloatArrayElements(samples, nullptr);
        if (data != nullptr) {
            struct whisper_full_params wp = whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
            wp.print_realtime = false;
            wp.print_progress = false;
            wp.print_timestamps = false;
            wp.print_special = false;
            wp.translate = false;
            wp.detect_language = false;
            wp.language = "fa";
            wp.n_threads = threads;
            wp.no_context = true;
            wp.single_segment = true;
            wp.no_timestamps = true;
            wp.temperature_inc = 0.0f;   // بدون تلاش‌های مکرر با دمای بالاتر؛ زمان پاسخ قابل پیش‌بینی می‌ماند
            wp.max_tokens = 64;          // شماره‌ی واحد کوتاه است؛ جلوی تکرارِ بی‌پایانِ مدل کوچک را می‌گیرد
            if (audio_ctx > 0) {
                wp.audio_ctx = audio_ctx;
            }

            const int rc = whisper_full(ctx, wp, data, static_cast<int>(n));
            env->ReleaseFloatArrayElements(samples, data, JNI_ABORT);

            if (rc == 0) {
                const int segments = whisper_full_n_segments(ctx);
                for (int i = 0; i < segments; i++) {
                    const char *piece = whisper_full_get_segment_text(ctx, i);
                    if (piece != nullptr) {
                        text += piece;
                    }
                }
            } else {
                LOGI("whisper_full failed: %d", rc);
            }
        }
    }

    jbyteArray out = env->NewByteArray(static_cast<jsize>(text.size()));
    if (out != nullptr && !text.empty()) {
        env->SetByteArrayRegion(out, 0, static_cast<jsize>(text.size()),
                                reinterpret_cast<const jbyte *>(text.data()));
    }
    return out;
}

extern "C" JNIEXPORT void JNICALL
Java_ir_semnan_unitvoice_LocalWhisper_nativeFree(JNIEnv *, jclass, jlong handle) {
    struct whisper_context *ctx = reinterpret_cast<struct whisper_context *>(handle);
    if (ctx != nullptr) {
        whisper_free(ctx);
    }
}
