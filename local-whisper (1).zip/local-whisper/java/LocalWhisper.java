package ir.semnan.unitvoice;

import android.content.Context;
import android.content.res.AssetFileDescriptor;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/**
 * Whisper روی خود گوشی (با whisper.cpp).
 *
 * فایل مدل (فرمت ggml) هنگام ساخت اپ داخل پوشه‌ی assets/models قرار می‌گیرد.
 * بار اول از داخل اپ به حافظه‌ی داخلی گوشی کپی می‌شود و بعد از آن مستقیم از همانجا خوانده می‌شود.
 *
 * اگر کتابخانه‌ی native یا فایل مدل داخل اپ نباشد، isAvailable() مقدار false می‌دهد
 * و اپ فقط در حالت سرور کار می‌کند.
 */
final class LocalWhisper {

    /** مسیر مدل داخل assets (توسط ورک‌فلو ساخت اپ گذاشته می‌شود). */
    static final String MODEL_ASSET = "models/whisper-model.bin";

    private static final String MODEL_FILE = "whisper-model.bin";
    private static final int SAMPLE_RATE = 16000;
    private static final int MIN_SAMPLES = (int) (SAMPLE_RATE * 1.2);   // Whisper کمتر از ۱ ثانیه را قبول نمی‌کند
    private static final boolean SHORT_AUDIO_CONTEXT = true;            // برای ضبط کوتاه سریع‌تر می‌شود

    private static final boolean LIB_OK;
    private static volatile long ctx = 0L;   // volatile: رابط کاربری بدون قفل می‌پرسد «آماده است؟»

    static {
        boolean ok = false;
        try {
            System.loadLibrary("whisper_jni");
            ok = true;
        } catch (Throwable ignored) {
            // کتابخانه داخل این نسخه‌ی اپ نیست
        }
        LIB_OK = ok;
    }

    private LocalWhisper() {
    }

    private static native long nativeInit(String modelPath, boolean flashAttn);

    private static native String nativeInfo();

    private static native byte[] nativeTranscribe(long handle, float[] samples, int threads, int audioCtx);

    private static native void nativeFree(long handle);

    /** آیا این نسخه‌ی اپ هم کتابخانه و هم فایل مدل را دارد؟ */
    static boolean isAvailable(Context c) {
        if (!LIB_OK) {
            return false;
        }
        try (InputStream in = c.getAssets().open(MODEL_ASSET)) {
            return in != null;
        } catch (IOException e) {
            return false;
        }
    }

    /** بدون قفل است تا وقتی مدل در حال بارگذاری/اجراست، صفحه هرگز منتظر نماند. */
    static boolean isReady() {
        return ctx != 0L;
    }

    /** فهرست ویژگی‌های پردازنده از دید whisper.cpp (فقط برای گزارش خطا). */
    static String systemInfo() {
        if (!LIB_OK) {
            return "";
        }
        try {
            String s = nativeInfo();
            return s == null ? "" : s.trim();
        } catch (Throwable t) {
            return "";
        }
    }

    /** مدل را (در صورت نیاز) کپی و بارگذاری می‌کند. بار اول چند ثانیه طول می‌کشد. */
    static synchronized void ensureLoaded(Context c) throws IOException {
        if (ctx != 0L) {
            return;
        }
        File model = new File(c.getFilesDir(), MODEL_FILE);
        long assetLen = assetLength(c);
        if (!model.exists() || (assetLen > 0 && model.length() != assetLen)) {
            copyAsset(c, model);
        }
        // سطح ایمنی ۲: flash-attention خاموش می‌شود (مسیر کلاسیک و محافظه‌کارانه‌تر)
        final boolean flash = CrashReport.level() < 2;
        CrashReport.nativeBegin("init");
        long handle = nativeInit(model.getAbsolutePath(), flash);
        CrashReport.nativeEnd();
        if (handle == 0L) {
            model.delete();   // اگر فایل خراب بوده، دفعه‌ی بعد دوباره کپی شود
            throw new IOException("مدل روی گوشی بارگذاری نشد (شاید حافظه کم است)");
        }
        ctx = handle;
    }

    /** صدای خام PCM (۱۶ کیلوهرتز، ۱۶ بیت، تک‌کاناله) را به متن تبدیل می‌کند. */
    static synchronized String transcribe(byte[] pcm) throws IOException {
        if (ctx == 0L) {
            throw new IOException("مدل آماده نیست");
        }
        int n = pcm.length / 2;
        float[] samples = new float[Math.max(n, MIN_SAMPLES)];   // بقیه صفر (سکوت) می‌ماند
        for (int i = 0; i < n; i++) {
            int lo = pcm[2 * i] & 0xFF;
            int hi = pcm[2 * i + 1];
            samples[i] = ((hi << 8) | lo) / 32768f;
        }
        // ضبط‌های ما حداکثر ۱۰ ثانیه است؛ پنجره‌ی ۳۰ ثانیه‌ای Whisper را کوتاه می‌کنیم تا چند برابر سریع‌تر شود.
        // (حداقل ۵۰۰ واحد = ۱۰ ثانیه؛ برای دقت بیشتر پنجره را خیلی کوچک نمی‌کنیم.)
        // اگر اپ قبلاً وسط تشخیص بسته شده باشد (CrashReport.level() > 0)، با مسیر استانداردِ
        // whisper.cpp (پنجره‌ی کامل ۳۰ ثانیه) و در سطح ۲ با یک رشته ادامه می‌دهیم.
        final int level = CrashReport.level();
        double seconds = samples.length / (double) SAMPLE_RATE;
        int audioCtx = 0;   // ۰ = پیش‌فرض (۳۰ ثانیه)
        if (SHORT_AUDIO_CONTEXT && level == 0 && seconds <= 12.0) {
            audioCtx = Math.min(1500, Math.max(500, (int) Math.ceil(seconds * 50.0) + 150));
        }
        int threads = level >= 2 ? 1 : Math.max(2, Math.min(4, Runtime.getRuntime().availableProcessors()));
        CrashReport.nativeBegin("run");
        byte[] out = nativeTranscribe(ctx, samples, threads, audioCtx);
        CrashReport.nativeEnd();
        if (out == null) {
            return "";
        }
        return new String(out, StandardCharsets.UTF_8).trim();
    }

    /** حافظه‌ی مدل را آزاد می‌کند (وقتی اپ به پس‌زمینه می‌رود). */
    static synchronized void release() {
        if (ctx != 0L) {
            nativeFree(ctx);
            ctx = 0L;
        }
    }

    private static long assetLength(Context c) {
        try (AssetFileDescriptor fd = c.getAssets().openFd(MODEL_ASSET)) {
            return fd.getLength();
        } catch (IOException e) {
            return -1L;   // فایل فشرده است؛ اندازه معلوم نیست
        }
    }

    private static void copyAsset(Context c, File target) throws IOException {
        File tmp = new File(target.getPath() + ".tmp");
        try (InputStream in = c.getAssets().open(MODEL_ASSET);
             OutputStream out = new FileOutputStream(tmp)) {
            byte[] buf = new byte[1 << 20];
            int len;
            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
            }
            out.flush();
        } catch (IOException e) {
            tmp.delete();
            throw e;
        }
        if (target.exists() && !target.delete()) {
            tmp.delete();
            throw new IOException("فایل قدیمی مدل پاک نشد");
        }
        if (!tmp.renameTo(target)) {
            tmp.delete();
            throw new IOException("ذخیره‌ی مدل روی گوشی ناموفق بود");
        }
    }
}
