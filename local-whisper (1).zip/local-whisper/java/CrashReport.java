package ir.semnan.unitvoice;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.ApplicationExitInfo;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Build;

import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * «جعبه‌سیاه» ساده: اگر اپ ناگهان بسته شود، دفعه‌ی بعد که باز می‌شود روی صفحه می‌نویسد
 * کجا بسته شد و اندروید چه دلیلی ثبت کرده است. همچنین بعد از هر بسته‌شدنِ ناگهانی در
 * مرحله‌ی تشخیص، تنظیمات موتور تشخیص را یک پله «ایمن‌تر» می‌کند.
 *
 * سطح ایمنی: ۰ = عادی؛ ۱ = پنجره‌ی کامل صدا (مسیر استاندارد whisper.cpp)؛
 * ۲ = بدون flash-attention و فقط با یک رشته (کندتر ولی محافظه‌کارانه‌ترین حالت).
 */
final class CrashReport {

    static final String IDLE = "idle";
    static final String RECORDING = "recording";
    static final String PROCESSING = "processing";

    private static final String PREFS = "crash_report";
    private static final String K_STAGE = "stage";
    private static final String K_NATIVE = "native";
    private static final String K_PID = "pid";
    private static final String K_LEVEL = "level";
    private static final String K_JAVA = "java_trace";
    private static final String K_REPORT = "report";
    private static final int MAX_LEVEL = 2;

    private static Context app;
    private static volatile int level = 0;

    private CrashReport() {
    }

    // ------------------------------------------------------------------ راه‌اندازی

    /** باید یک بار، اول onCreate صدا زده شود. گزارش دفعه‌ی قبل را می‌سازد و سطح ایمنی را تعیین می‌کند. */
    static synchronized void begin(Context c) {
        try {
            app = c.getApplicationContext() != null ? c.getApplicationContext() : c;
            SharedPreferences sp = prefs();
            level = Math.max(0, Math.min(MAX_LEVEL, sp.getInt(K_LEVEL, 0)));

            final String stage = sp.getString(K_STAGE, IDLE);
            final String nat = sp.getString(K_NATIVE, "");
            final String javaTrace = sp.getString(K_JAVA, "");
            final int oldPid = sp.getInt(K_PID, -1);
            final int myPid = android.os.Process.myPid();

            if (oldPid != -1 && oldPid != myPid) {
                boolean inFlight = !nat.isEmpty() || PROCESSING.equals(stage) || RECORDING.equals(stage);
                if (inFlight || !javaTrace.isEmpty()) {
                    ExitText exit = describeExit(oldPid);
                    if (!exit.userKilled) {
                        if (!nat.isEmpty() || PROCESSING.equals(stage)) {
                            level = Math.min(MAX_LEVEL, level + 1);
                        }
                        String report = buildReport(stage, nat, javaTrace, exit.text);
                        sp.edit().putString(K_REPORT, report).putInt(K_LEVEL, level).commit();
                    }
                }
            }
            sp.edit().putString(K_STAGE, IDLE).putString(K_NATIVE, "").putString(K_JAVA, "")
                    .putInt(K_PID, myPid).commit();

            final Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
            Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
                try {
                    StringWriter sw = new StringWriter();
                    e.printStackTrace(new PrintWriter(sw));
                    String tr = sw.toString();
                    if (tr.length() > 1600) {
                        tr = tr.substring(0, 1600);
                    }
                    prefs().edit().putString(K_JAVA, tr).commit();
                } catch (Throwable ignored) {
                    // نوشتن گزارش نباید خودش مشکل بسازد
                }
                if (previous != null) {
                    previous.uncaughtException(t, e);
                }
            });
        } catch (Throwable ignored) {
            // گزارش‌گیری اختیاری است؛ اگر خودش خطا داد، اپ باید عادی کار کند
        }
    }

    /** اگر دفعه‌ی قبل مشکلی بوده، پنجره‌ی گزارش را نشان می‌دهد (تا کاربر «باشه» نزند می‌ماند). */
    static void showPendingIfAny(Activity a) {
        try {
            final String report = prefs().getString(K_REPORT, "");
            if (report.isEmpty()) {
                return;
            }
            new AlertDialog.Builder(a)
                    .setTitle("دفعه‌ی قبل اپ ناگهان بسته شد")
                    .setMessage(report)
                    .setCancelable(false)
                    .setPositiveButton("باشه، دیدم", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            try {
                                prefs().edit().putString(K_REPORT, "").commit();
                            } catch (Throwable ignored) {
                                // بی‌اهمیت
                            }
                        }
                    })
                    .show();
        } catch (Throwable ignored) {
            // نمایش گزارش اختیاری است
        }
    }

    /** سطح ایمنی فعلی (۰ تا ۲). */
    static int level() {
        return level;
    }

    // ------------------------------------------------------------------ ردپا (breadcrumb)

    /** مرحله‌ی کلیِ کار: IDLE، RECORDING یا PROCESSING. */
    static void mark(String stage) {
        put(K_STAGE, stage);
    }

    /** درست قبل از فراخوانی کدِ native (init یا run). اگر همان‌جا اپ بمیرد، همین در گزارش می‌آید. */
    static void nativeBegin(String what) {
        put(K_NATIVE, what);
    }

    static void nativeEnd() {
        put(K_NATIVE, "");
    }

    private static void put(String key, String value) {
        try {
            if (app != null) {
                prefs().edit().putString(key, value).commit();
            }
        } catch (Throwable ignored) {
            // بی‌اهمیت
        }
    }

    private static SharedPreferences prefs() {
        return app.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    // ------------------------------------------------------------------ ساختن گزارش

    private static final class ExitText {
        String text = "";
        boolean userKilled = false;
    }

    private static String stageFa(String stage, String nat) {
        if ("init".equals(nat)) {
            return "بارگذاری مدل روی گوشی";
        }
        if ("run".equals(nat)) {
            return "تشخیص روی گوشی (داخل موتور Whisper)";
        }
        if (RECORDING.equals(stage)) {
            return "ضبط صدا";
        }
        if (PROCESSING.equals(stage)) {
            return "پردازش بعد از ضبط";
        }
        return "نامشخص";
    }

    private static String buildReport(String stage, String nat, String javaTrace, String exitText) {
        StringBuilder sb = new StringBuilder();
        sb.append("لطفاً از همین صفحه عکس بگیرید و بفرستید.\n\n");
        sb.append("مرحله‌ای که بسته شد: ").append(stageFa(stage, nat)).append('\n');
        if (!exitText.isEmpty()) {
            sb.append(exitText);
        } else {
            sb.append("اندروید دلیلی ثبت نکرده است.\n");
        }
        if (!javaTrace.isEmpty()) {
            sb.append("\nخطای برنامه:\n").append(javaTrace).append('\n');
        }
        sb.append("\n").append(deviceText());
        if (level > 0) {
            sb.append("\nاین بار با تنظیمات ایمن‌تر (سطح ").append(level).append(") امتحان می‌شود.");
        }
        return sb.toString();
    }

    private static String deviceText() {
        StringBuilder sb = new StringBuilder();
        sb.append("گوشی: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL)
                .append(" / اندروید ").append(Build.VERSION.RELEASE).append('\n');
        try {
            ActivityManager am = (ActivityManager) app.getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            sb.append("حافظه‌ی رم: کل ").append(mi.totalMem / (1024 * 1024)).append(" مگابایت، آزاد ")
                    .append(mi.availMem / (1024 * 1024)).append(" مگابایت\n");
        } catch (Throwable ignored) {
            // بی‌اهمیت
        }
        String info = LocalWhisper.systemInfo();
        if (!info.isEmpty()) {
            sb.append("ویژگی‌های پردازنده: ").append(info).append('\n');
        }
        return sb.toString();
    }

    private static String reasonName(int r) {
        switch (r) {
            case 1: return "خروج عادی (EXIT_SELF)";
            case 2: return "کشته‌شدن با سیگنال (SIGNALED)";
            case 3: return "کمبود حافظه (LOW_MEMORY)";
            case 4: return "خطای جاوا (CRASH)";
            case 5: return "خرابی کد native (CRASH_NATIVE)";
            case 6: return "پاسخ‌ندادن (ANR)";
            case 7: return "خطا در شروع (INITIALIZATION_FAILURE)";
            case 8: return "تغییر مجوز (PERMISSION_CHANGE)";
            case 9: return "مصرف بیش از حد منابع (EXCESSIVE_RESOURCE_USAGE)";
            case 10: return "بسته‌شدن توسط کاربر (USER_REQUESTED)";
            case 11: return "توقف اجباری توسط کاربر (USER_STOPPED)";
            case 12: return "مرگ وابستگی (DEPENDENCY_DIED)";
            case 14: return "فریز شدن برنامه (FREEZER)";
            default: return "سایر (کد " + r + ")";
        }
    }

    /** از «تاریخچه‌ی علت بسته‌شدن» اندروید (نسخه‌ی ۱۱ به بالا) می‌پرسد. */
    private static ExitText describeExit(int oldPid) {
        ExitText out = new ExitText();
        if (Build.VERSION.SDK_INT < 30) {
            out.text = "این گوشی (اندروید پایین‌تر از ۱۱) علت بسته‌شدن را ثبت نمی‌کند.\n";
            return out;
        }
        try {
            ActivityManager am = (ActivityManager) app.getSystemService(Context.ACTIVITY_SERVICE);
            List<ApplicationExitInfo> list = am.getHistoricalProcessExitReasons(null, 0, 10);
            ApplicationExitInfo hit = null;
            if (list != null) {
                for (ApplicationExitInfo e : list) {
                    if (e.getPid() == oldPid) {
                        hit = e;
                        break;
                    }
                }
                if (hit == null && !list.isEmpty()) {
                    hit = list.get(0);
                }
            }
            if (hit == null) {
                return out;
            }
            int r = hit.getReason();
            if (r == 1 || r == 10 || r == 11) {
                out.userKilled = true;
            }
            StringBuilder sb = new StringBuilder();
            sb.append("علت از دید اندروید: ").append(reasonName(r)).append('\n');
            String d = hit.getDescription();
            if (d != null && !d.isEmpty()) {
                sb.append("توضیح: ").append(d).append('\n');
            }
            sb.append("کد وضعیت: ").append(hit.getStatus()).append('\n');
            long rss = hit.getRss();
            if (rss > 0) {
                sb.append("حافظه‌ی مصرفی هنگام بسته‌شدن: ").append(rss / 1024).append(" مگابایت\n");
            }
            if (r == 5 || r == 2) {
                String t = traceStrings(hit);
                if (!t.isEmpty()) {
                    sb.append("جزئیات فنی:\n").append(t).append('\n');
                }
            }
            out.text = sb.toString();
        } catch (Throwable ignored) {
            out.text = "";
        }
        return out;
    }

    private static final Pattern KEYWORDS = Pattern.compile(
            "(?i)(signal|SIG[A-Z]{3,}|abort|assert|ggml|whisper|libc\\.so|\\.so|fault|backtrace|libart)");

    /** از فایل tombstone (فرمت باینری) فقط متن‌های خوانا را بیرون می‌کشد. */
    private static String traceStrings(ApplicationExitInfo e) {
        try (InputStream in = e.getTraceInputStream()) {
            if (in == null) {
                return "";
            }
            byte[] buf = new byte[300 * 1024];
            int total = 0;
            int n;
            while (total < buf.length && (n = in.read(buf, total, buf.length - total)) > 0) {
                total += n;
            }
            List<String> lines = new ArrayList<>();
            StringBuilder run = new StringBuilder();
            for (int i = 0; i <= total; i++) {
                int b = i < total ? (buf[i] & 0xFF) : 0;
                if (b >= 32 && b < 127) {
                    run.append((char) b);
                } else {
                    if (run.length() >= 5) {
                        String s = run.toString();
                        if (KEYWORDS.matcher(s).find()) {
                            if (s.length() > 90) {
                                s = s.substring(0, 90);
                            }
                            if (!lines.contains(s)) {
                                lines.add(s);
                            }
                        }
                    }
                    run.setLength(0);
                }
                if (lines.size() >= 8) {
                    break;
                }
            }
            StringBuilder sb = new StringBuilder();
            for (String s : lines) {
                sb.append(s).append('\n');
            }
            return sb.toString();
        } catch (Throwable ignored) {
            return "";
        }
    }
}
