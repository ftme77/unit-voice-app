package ir.semnan.unitvoice;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * استخراج‌گر شماره‌ی واحد از متن فارسی — نسخه‌ی ۲ (قاعده‌محور).
 * ترجمه‌ی مستقیم از فایل unit_number_extractor.py تا روی خود گوشی هم همان نتیجه‌ی سرور به دست آید.
 *
 * ورودی: متن تشخیص‌داده‌شده؛ خروجی: عدد ۰ تا ۹۹۹ یا null (= «پیدا نشد»).
 * اگر ساختار عدد مشکوک باشد، به‌جای حدس‌زدن null برمی‌گرداند.
 */
final class UnitExtractor {

    private UnitExtractor() {
    }

    // گروه هر کلمه: 0=صفر، 1=یکان، 2=ده تا نوزده و دهگان‌ها، 3=صدگان
    private static final Map<String, Integer> CATEGORY = new HashMap<>();
    private static final Map<String, Integer> VALUE = new HashMap<>();
    private static final Set<String> TEENS = new HashSet<>();
    private static final Map<String, String> VARIANTS = new HashMap<>();

    private static void add(String word, int value, int category, boolean teen) {
        CATEGORY.put(word, category);
        VALUE.put(word, value);
        if (teen) {
            TEENS.add(word);
        }
    }

    static {
        add("\u0635\u0641\u0631", 0, 0, false);
        add("\u06cc\u06a9", 1, 1, false);
        add("\u062f\u0648", 2, 1, false);
        add("\u0633\u0647", 3, 1, false);
        add("\u0686\u0647\u0627\u0631", 4, 1, false);
        add("\u067e\u0646\u062c", 5, 1, false);
        add("\u0634\u0634", 6, 1, false);
        add("\u0647\u0641\u062a", 7, 1, false);
        add("\u0647\u0634\u062a", 8, 1, false);
        add("\u0646\u0647", 9, 1, false);
        add("\u062f\u0647", 10, 2, true);
        add("\u06cc\u0627\u0632\u062f\u0647", 11, 2, true);
        add("\u062f\u0648\u0627\u0632\u062f\u0647", 12, 2, true);
        add("\u0633\u06cc\u0632\u062f\u0647", 13, 2, true);
        add("\u0686\u0647\u0627\u0631\u062f\u0647", 14, 2, true);
        add("\u067e\u0627\u0646\u0632\u062f\u0647", 15, 2, true);
        add("\u0634\u0627\u0646\u0632\u062f\u0647", 16, 2, true);
        add("\u0647\u0641\u062f\u0647", 17, 2, true);
        add("\u0647\u062c\u062f\u0647", 18, 2, true);
        add("\u0646\u0648\u0632\u062f\u0647", 19, 2, true);
        add("\u0628\u06cc\u0633\u062a", 20, 2, false);
        add("\u0633\u06cc", 30, 2, false);
        add("\u0686\u0647\u0644", 40, 2, false);
        add("\u067e\u0646\u062c\u0627\u0647", 50, 2, false);
        add("\u0634\u0635\u062a", 60, 2, false);
        add("\u0647\u0641\u062a\u0627\u062f", 70, 2, false);
        add("\u0647\u0634\u062a\u0627\u062f", 80, 2, false);
        add("\u0646\u0648\u062f", 90, 2, false);
        add("\u0635\u062f", 100, 3, false);
        add("\u062f\u0648\u06cc\u0633\u062a", 200, 3, false);
        add("\u0633\u06cc\u0635\u062f", 300, 3, false);
        add("\u0686\u0647\u0627\u0631\u0635\u062f", 400, 3, false);
        add("\u067e\u0627\u0646\u0635\u062f", 500, 3, false);
        add("\u0634\u0634\u0635\u062f", 600, 3, false);
        add("\u0647\u0641\u062a\u0635\u062f", 700, 3, false);
        add("\u0647\u0634\u062a\u0635\u062f", 800, 3, false);
        add("\u0646\u0647\u0635\u062f", 900, 3, false);
        VARIANTS.put("\u0634\u06cc\u0634", "\u0634\u0634");
        VARIANTS.put("\u0647\u06cc\u062c\u062f\u0647", "\u0647\u062c\u062f\u0647");
        VARIANTS.put("\u0647\u06cc\u0698\u062f\u0647", "\u0647\u062c\u062f\u0647");
        VARIANTS.put("\u0647\u0698\u062f\u0647", "\u0647\u062c\u062f\u0647");
        VARIANTS.put("\u0647\u06cc\u0641\u062f\u0647", "\u0647\u0641\u062f\u0647");
        VARIANTS.put("\u067e\u0648\u0646\u0632\u062f\u0647", "\u067e\u0627\u0646\u0632\u062f\u0647");
        VARIANTS.put("\u0634\u0648\u0646\u0632\u062f\u0647", "\u0634\u0627\u0646\u0632\u062f\u0647");
        VARIANTS.put("\u0686\u0627\u0631\u062f\u0647", "\u0686\u0647\u0627\u0631\u062f\u0647");
        VARIANTS.put("\u0686\u0627\u0631", "\u0686\u0647\u0627\u0631");
        VARIANTS.put("\u0686\u0644", "\u0686\u0647\u0644");
        VARIANTS.put("\u067e\u0646\u062c\u0627", "\u067e\u0646\u062c\u0627\u0647");
        VARIANTS.put("\u0634\u06cc\u0634\u0635\u062f", "\u0634\u0634\u0635\u062f");
        VARIANTS.put("\u0686\u0627\u0631\u0635\u062f", "\u0686\u0647\u0627\u0631\u0635\u062f");
        VARIANTS.put("\u067e\u0648\u0646\u0635\u062f", "\u067e\u0627\u0646\u0635\u062f");
        VARIANTS.put("\u0647\u0641\u0635\u062f", "\u0647\u0641\u062a\u0635\u062f");
        VARIANTS.put("\u0647\u0634\u0635\u062f", "\u0647\u0634\u062a\u0635\u062f");
        VARIANTS.put("\u0646\u064f\u0647\u0635\u062f", "\u0646\u0647\u0635\u062f");
    }

    private static final Pattern MARKS = Pattern.compile("[\\u064B-\\u065F\\u0640]");
    // توجه: اندروید پرچم Pattern.UNICODE_CHARACTER_CLASS را پشتیبانی نمی‌کند (کلاس را موقع بارگذاری می‌ترکاند).
    // به‌جای آن، فاصله‌ی یونیکد را صریح می‌نویسیم تا روی جاوای معمولی و اندروید دقیقاً یک نتیجه بدهد.
    private static final String WS = "\\t\\n\\u000B\\f\\r \\u0085\\u00A0\\u1680\\u2000-\\u200A\\u2028\\u2029\\u202F\\u205F\\u3000";
    private static final Pattern NOT_WORD = Pattern.compile("[^\\p{L}\\p{N}_" + WS + "]");
    private static final Pattern SPACES = Pattern.compile("[" + WS + "]+");
    private static final Pattern DIGITS = Pattern.compile("\\p{Nd}+");

    private static final String VAV = "و";   // «و»

    static String normalizeText(String text) {
        String t = text.replace('ي', 'ی').replace('ك', 'ک');   // ي ← ی ، ك ← ک
        t = t.replace("‌", "");                       // نیم‌فاصله حذف شود (شیش‌صد ← شیشصد)
        t = MARKS.matcher(t).replaceAll("");               // اعراب و کشیده
        t = NOT_WORD.matcher(t).replaceAll(" ");
        t = SPACES.matcher(t).replaceAll(" ").trim();
        return t;
    }

    /** شکل رسمی کلمه‌ی عددی، یا null اگر عدد نیست. */
    private static String canon(String word) {
        String w = VARIANTS.get(word);
        if (w == null) {
            w = word;
        }
        return CATEGORY.containsKey(w) ? w : null;
    }

    /** کلمه‌های چسبیده مثل «چلوسه» و «صدو» به «چل و سه» و «صد و» شکسته می‌شوند. */
    private static List<String> tokens(String norm) {
        List<String> out = new ArrayList<>();
        if (norm.isEmpty()) {
            return out;
        }
        for (String tok : norm.split(" ")) {
            if (tok.isEmpty()) {
                continue;
            }
            if (canon(tok) != null || tok.equals(VAV)) {
                out.add(tok);
                continue;
            }
            if (tok.contains(VAV)) {
                boolean split = false;
                for (int i = 0; i < tok.length(); i++) {
                    if (tok.charAt(i) != VAV.charAt(0)) {
                        continue;
                    }
                    String left = tok.substring(0, i);
                    String right = tok.substring(i + 1);
                    if (canon(left) != null && (right.isEmpty() || canon(right) != null)) {
                        out.add(left);
                        out.add(VAV);
                        if (!right.isEmpty()) {
                            out.add(right);
                        }
                        split = true;
                        break;
                    }
                }
                if (!split) {
                    out.add(tok);
                }
            } else {
                out.add(tok);
            }
        }
        return out;
    }

    /** عدد صحیح ۰ تا ۹۹۹ یا null (= پیدا نشد). */
    static Integer extract(String rawText) {
        if (rawText == null) {
            return null;
        }

        // اگر دقیقاً یک عدد با رقم نوشته شده باشد (فارسی، عربی یا لاتین)، همان را برمی‌گردان
        List<String> digitGroups = new ArrayList<>();
        Matcher m = DIGITS.matcher(rawText);
        while (m.find()) {
            digitGroups.add(m.group());
        }
        if (digitGroups.size() == 1) {
            String g = digitGroups.get(0);
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < g.length(); i++) {
                sb.append(Character.digit(g.codePointAt(i), 10));
            }
            String s = sb.toString().replaceFirst("^0+(?=.)", "");
            if (s.length() > 3) {
                return null;
            }
            return Integer.parseInt(s);
        }

        List<String> toks = tokens(normalizeText(rawText));
        List<String> words = new ArrayList<>();
        List<Integer> pos = new ArrayList<>();
        for (int i = 0; i < toks.size(); i++) {
            String c = canon(toks.get(i));
            if (c != null) {
                words.add(c);
                pos.add(i);
            }
        }
        if (words.isEmpty()) {
            return null;
        }

        // --- بررسی ساختار عدد: صدگان ← دهگان (یا ده‌تا‌نوزده) ← یکان؛ هر گروه حداکثر یک بار ---
        if (words.size() > 1) {
            for (String w : words) {
                if (CATEGORY.get(w) == 0) {      // «صفر» همراه عدد دیگر معنی ندارد
                    return null;
                }
            }
            for (int i = 0; i + 1 < words.size(); i++) {
                String a = words.get(i);
                String b = words.get(i + 1);
                if (CATEGORY.get(b) >= CATEGORY.get(a)) {      // ترتیب باید کاهشی باشد
                    return null;
                }
                if (TEENS.contains(a) && CATEGORY.get(b) == 1) {   // «پانزده سه» معنی ندارد
                    return null;
                }
            }
        }

        // --- «و» معلق: بعد از صدگان/دهگان «و» آمده ولی عددی بعدش نیست ---
        for (int k = 0; k < words.size(); k++) {
            String w = words.get(k);
            int p = pos.get(k);
            int cat = CATEGORY.get(w);
            if ((cat == 2 || cat == 3) && !TEENS.contains(w)) {
                if (p + 1 < toks.size() && toks.get(p + 1).equals(VAV)) {
                    String nxt = p + 2 < toks.size() ? toks.get(p + 2) : null;
                    if (nxt == null || canon(nxt) == null) {
                        return null;
                    }
                }
            }
        }

        int sum = 0;
        for (String w : words) {
            sum += VALUE.get(w);
        }
        return sum;
    }
}
